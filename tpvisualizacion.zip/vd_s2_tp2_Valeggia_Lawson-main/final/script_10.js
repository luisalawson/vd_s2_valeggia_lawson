
d3.csv('astronautas.csv', d3.autoType).then(data => {
    let chart_10 = Plot.plot({
      marks:[

      Plot.barY(
        data, 
        
        Plot.groupX(
        {y:"mean"},
        {y:'eva_mision_hs',
        x:'anio_mision', fill:'darkcyan'
      }
        )),
  
      ],
      grid: true,
      color:{
        legend: true,
        scheme: 'set2',
 
      },
      y:{
        domain: [0,20],
        label: 'Promedio horas extravehiculares'
      },
      x:{
        label: 'Año de misión'
      }
    }
    
    )
    d3.select('#chart_10').append(() => chart_10)
})

