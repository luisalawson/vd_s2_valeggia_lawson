d3.csv('astronautas.csv', d3.autoType).then(data => {
  let chart_11 = Plot.plot({
    marginBottom: 80,
    marks:[
      
    Plot.barY(
      
      data, 
      Plot.groupX(
      {y:"mean"},
      {y:'mision_hs',
      x:'ocupacion', fill:'darkcyan'
    }
      )),
    ],
    grid: true,
    color:{
      legend: true,
      scheme: 'set2',

    },
    y:{
      domain: [0,4500],
      label: 'Horas de misión'
    },
    x:{
      tickRotate:-20,
      label: 'Ocupación'
    }
  }
  )
  d3.select('#chart_11').append(() => chart_11)
})
