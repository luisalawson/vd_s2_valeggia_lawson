d3.csv('astronautas.csv', d3.autoType).then(data => {
    let chart_12 = Plot.plot({
        projection: "equirectangular",
        marks: [
          Plot.graticule(),
          Plot.geo(land, {fill: "#ccc"}),
          Plot.geo((data, {x:'count'},{y:'nacionalidad'}), {r: d => Math.exp(d.properties.mag)}),
          Plot.sphere()
        ]
      })
    d3.select('#chart_12').append(() => chart_12)
})