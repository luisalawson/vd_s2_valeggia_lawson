d3.csv('astronautas.csv', d3.autoType).then(data => {
  let chart_11 = Plot.plot({
    marginLeft: 100,
    marks: [
      Plot.barY(data, Plot.binY({x:'count'},{y:'mision_hs', fill:'darkcyan'})
      ),
    ],
    grid: true,
    x:{
      domain:[0,60],
      label: "Cantidad →"
    },
    y:{
      label: "Horas de Misión"
    }
  })
  d3.select('#chart_11').append(() => chart_11)
})


