// d3.csv('astronautas.csv', d3.autoType).then(data => {
//   let chart_6 = Plot.plot({
//     marks: [
//       Plot.barX(data, {
//         x: 'mision_hs',
//         y: 'anio_mision',
//       }),
//     ],
//     y: {
//       domain: d3.sort(data, (a, b) => d3.descending(a.mision_hs, b.mision_hs)).map(d => d.anio_mision),
//     },
//     x: {
//       grid: true,
//     },
//     height: 400,
//     marginLeft: 100,
//   })
//   d3.select('#chart_6').append(() => chart_6)
// })

d3.csv('astronautas.csv', d3.autoType).then(data => {
  let chart_6 = Plot.plot({
    height: 300,
    color:{
      scheme: "set2",
    },
    x: {
      label: "Edad →",
      nice: true
    },
    y: {
      grid: true,
      label: "← Femenino · Masculino →",
      labelAnchor: "center",
      tickFormat: Math.abs,
      domain: [-5, 12]
    },
    marks: [
      Plot.dot(data, Plot.stackY2({
        x: d => d.edad_mision,
        y: d => d.genero === "masculino" ? 1 : d.genero === "femenino" ? -1 : 0,
        fill: "genero"
      })),
      Plot.ruleY([0])
    ],
    
  })
  d3.select('#chart_6').append(() => chart_6)
})